import json
from urllib.parse import unquote

with open('converted_script.json') as json_file:
    data = json.load(json_file)


def get_inventory_id(url):
    for k, v in data.items():
        if url in k:
            try:
                previewSet = v['previewSet']
                id = previewSet['id']
            except KeyError:
                continue

            for k, v in data.items():
                if id+'.previews.0' in k:
                    image_url = v['url']
                    image_url = image_url.replace('{', '').replace('}', '')

            dict_data = {
                'id': id,
                'url': url,
                'image_url': unquote(unquote(image_url))
            }

            return dict_data


url = 'https://www.redbubble.com/i/mask/F-ck-Among-Us-Funny-by-nabilzd/57198628.9G0D8'
dict_data = get_inventory_id(url)
print(dict_data)